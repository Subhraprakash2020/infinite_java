package com.java.Day1;

public class StackS {
	
}
