package com.java.Day1;

import java.util.HashSet;

public class HashSetA {
	public static void main(String[] args) {
		
		//Creating a hashset
		HashSet<String> set=new HashSet<String>();  
		//Adding element in hashset
        set.add("Ravi");  
        set.add("Vijay");  
        set.add("Arun");  
        set.add("Sumit");  
        System.out.println("An initial list of elements: "+set);  
	}
}
